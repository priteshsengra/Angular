import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { CdkDragDrop } from '@angular/cdk/drag-drop';

import { MaterialModule } from '../shared/material/material.module';
import { DragDropComponent } from './drag-drop.component';

@NgModule({
  declarations: [
    DragDropComponent,
  ],
  imports: [
    CommonModule,
    MaterialModule,
    // CdkDragDrop,
  ],
  exports: [
    DragDropComponent,
  ]
})

export class DragDropModule { }
