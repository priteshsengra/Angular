import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';

import { Category } from 'src/app/shared/models/category';
import { NotificationService } from 'src/app/shared/service/notification.service';
import { ProductService } from 'src/app/shared/service/product.service';
import { _message } from 'src/app/shared/message';
import { _constant } from 'src/app/shared/constant';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})

export class ProductDetailComponent implements OnInit {
  _msg = _message;
  product_id: string;
  entity: string = 'product';
  entityText: string = 'Product';

  categories: Category[];
  filePath: string = '';
  selectedFileName: string = '';

  productForm: any;
  productFormObj: FormData = new FormData();

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private service: ProductService,
    private notificationService: NotificationService) {
    this.route.params.subscribe(params => {
      this.product_id = params.id || 0;
    });
  }

  ngOnInit(): void {
    this.productForm = this.formBuilder.group({
      'id': new FormControl(''),
      'name': new FormControl('', [Validators.required, Validators.minLength(5)]),
      'description': new FormControl('', Validators.maxLength(200)),
      'price': new FormControl('', [Validators.required, Validators.min(1)]),
      'quantity': new FormControl(''),
      'typeName': new FormControl(''),
      'categoryId': new FormControl('', Validators.required),
      'mfgDate': new FormControl('', Validators.required),
      'isActive': new FormControl(false),
      'fileSource': new FormControl(''),
      'files': new FormControl(null)
    });

    this.service.getProduct(this.product_id).subscribe(
      (data) => {
        let product = data.product;
        this.categories = data.categories;
        if (this.product_id) {
          this.filePath = product && product.fileSource
            ? (_constant.baseUrl + product.fileSource)
            : _constant.defaultImg;
          this.selectedFileName = this.filePath.toLowerCase().split('images/')[1];
        }
        this.initializeFormGroup(product);
      },
      error => {
        console.log(error);
      });
  }

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]),
    description: new FormControl('', Validators.maxLength(200)),
    price: new FormControl('', [Validators.required, Validators.min(1)]),
    quantity: new FormControl(''),
    typeName: new FormControl(''),
    categoryId: new FormControl('', Validators.required),
    mfgDate: new FormControl('', Validators.required),
    isActive: new FormControl(false),
    fileSource: new FormControl(''),
    files: new FormControl(null),
  });

  initializeFormGroup(product?: any) {
    if (product) {
      this.form.setValue({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        quantity: product.quantity,
        typeName: product.typeName,
        categoryId: product.categoryId,
        mfgDate: product.mfgDate,
        isActive: product.isActive,
        fileSource: product.fileSource,
        files: '',
      });
    }
    else {
      this.form.setValue({
        id: 0,
        name: '',
        description: '',
        price: '',
        quantity: '',
        typeName: '',
        categoryId: '',
        mfgDate: '',
        isActive: false,
        fileSource: '',
        files: '',
      });
    }
  }

  _fc = this.form.controls;
  _fv = this.form.value;

  onSubmit() {
    if (this.form.valid) {
      let formObj = this.form.value;
      formObj.id = Number(formObj.id);
      formObj.price = Number(formObj.price);
      formObj.quantity = Number(formObj.quantity);
      formObj.categoryId = Number(formObj.categoryId);
      formObj.mfgDate = this.datePipe.transform(formObj.mfgDate, 'yyyy-MM-dd');

      this.productFormObj.set('id', formObj.id);
      this.productFormObj.set('name', formObj.name);
      this.productFormObj.set('description', formObj.description);
      this.productFormObj.set('price', formObj.price);
      this.productFormObj.set('quantity', formObj.quantity);
      this.productFormObj.set('typeName', formObj.typeName);
      this.productFormObj.set('categoryId', formObj.categoryId);
      this.productFormObj.set('mfgDate', formObj.mfgDate);
      this.productFormObj.set('fileSource', formObj.fileSource);
      this.productFormObj.set('isActive', formObj.isActive);

      let isEdit = formObj.id && formObj.id > 0;
      let serviceCall = isEdit
        ? this.service.updateProduct(this.productFormObj)
        : this.service.createProduct(this.productFormObj);

      serviceCall.subscribe(
        (data: any) => {
          this.notificationService.success(isEdit
            ? _message.editSuccess.replace('{0}', this.entityText)
            : _message.addSuccess.replace('{0}', this.entityText)
          );
          this.gotoList();
        },
        (error: any) => {
          console.log(error);
          this.notificationService.danger(isEdit
            ? _message.editError.replace('{0}', this.entityText)
            : _message.addError.replace('{0}', this.entityText)
          );
          //   ? String.format(_message.editError, 'Product')
          //   : String.format(_message.addError, 'Product')
        });
    }
  }

  fileSelected(event: any) {
    if (event.target.files.length > 0) {
      let selectedFile = event.target.files[0];
      this.selectedFileName = selectedFile.name;
      const reader = new FileReader();
      reader.onload = () => {
        this.filePath = reader.result as string;
      }
      reader.readAsDataURL(selectedFile);

      this.productFormObj.delete('files');
      this.productFormObj.set('files', selectedFile);
    }

  }

  gotoList() {
    this.reset();
    this.router.navigate([this.entity]);
  }

  reset() {
    // this.productFormObj.delete('files');
    this.filePath = '';
    this.selectedFileName = '';
    this.form.reset();
    this.initializeFormGroup();
  }

}
