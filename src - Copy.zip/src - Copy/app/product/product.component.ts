import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { of, pipe } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { ProductService } from '../shared/service/product.service';
import { ColumnConfig, _column } from '../shared/configs/columns';
import { TableConfig } from '../shared/configs/tables';
import { _constant } from '../shared/constant';
import { _button } from '../shared/configs/buttons';
import { _message } from '../shared/message';
import { DialogService } from '../shared/service/dialog.service';
import { NotificationService } from '../shared/service/notification.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  constructor(private router: Router,
    private service: ProductService,
    private notificationService: NotificationService,
    private dialogService: DialogService) { }

  @ViewChild('productGrid', { static: false }) productGrid?: any;
  table: TableConfig;

  columns: ColumnConfig[] = [
    {
      name: 'Id',
      field: 'id',
      type: 'number',
      // isHidden: true,
      isExpand: true,
    },
    {
      name: 'Name',
      field: 'name',
      type: 'string',
    },
    {
      name: 'Description',
      field: 'description',
      type: 'string',
      isExpand: true,
    },
    {
      name: 'Price',
      field: 'price',
      type: 'currency',
    },
    {
      name: 'Quantity',
      field: 'quantity',
      type: 'number',
    },
    {
      name: 'Type',
      field: 'typeName',
      type: 'string',
      isExpand: true,
    },
    {
      name: 'Category',
      field: 'category',
      type: 'number',
    },
    {
      name: 'Mfg. Date',
      field: 'mfgDate',
      type: 'date',
      isExpand: true,
    },
    {
      name: 'Active',
      field: 'isActive',
      type: 'checkbox',
    },
    {
      name: 'File',
      field: 'fileSource',
      type: 'file',
      isExpand: true,
    }
  ];

  addCallback = () => {
    this.router.navigate([this.table.tableId + '/add']);
  }

  addBtn: any = {
    name: 'add',
    title: 'Add',
    color: 'accent',
    role: 'add',
    callback: this.addCallback
  };

  editCallback = (record: any) => {
    this.router.navigate([this.table.tableId + '/edit/' + record.id]);
  }

  editBtn: any = {
    name: 'edit',
    title: 'Edit',
    color: 'primary',
    role: 'action',
    callback: this.editCallback
  };

  deleteCallback = (record: any) => {
    this.dialogService.openConfirmDialog(_message.deleteConfirm.replace('{0}', this.table.header))
      .afterClosed().subscribe((res: any) => {
        if (res) {
          this.service.deleteProduct(record.id).subscribe(
            () => {
              this.notificationService.success(_message.deleteSuccess.replace('{0}', this.table.header));
              this.productGrid.refreshDataSource();
            },
            (errObj: any) => {
              this.notificationService.danger(errObj.error.Message);
            });
        }
      });
  }

  deleteBtn: any = {
    name: 'delete',
    title: 'Delete',
    color: 'warn',
    role: 'action',
    callback: this.deleteCallback
  };

  getGridData = (paging?: any, categoryId?: any) => {
    return this.service.listProduct(paging, categoryId);
  }

  getExpandData = (id: any) => {
    return this.service.expandProduct(id);
  }

  displayedColumns = this.columns
    .filter(column => !column.isExpand && !column.isHidden)
    .map(column => column.field);

  expandedColumns = pipe(
    filter((column: any) => column.isExpand && !column.isHidden)
    , map((column: any) => column.field)
  )(of(this.columns));

  ngOnInit() {
    this.setTableConfig();
  }

  setTableConfig() {
    this.table = {
      tableId: 'product',
      header: 'Product',
      columns: this.columns,
      buttons: [this.editBtn, this.deleteBtn],
      dataSource: this.getGridData,
      expandSource: this.getExpandData,
      showAdd: true,
      showSearch: true,
      showFilter: true,
      showAction: true,
      // showIndex: false,
      addBtn: this.addBtn,
      expandBtn: _button.expand,
      displayedColumns: [_column.expand.field, _column.index.field].concat(this.displayedColumns),
      expandedColumns: this.expandedColumns,
      defaultSort: { sortField: 'id', sortAsc: false }
    }

    this.table.addBtn.show = this.table.showAdd;

    if (this.table.showAction) {
      this.table.displayedColumns.push(_column.action.field);
      this.table.buttons.forEach((button: any) => {
        // edit & delete button visibility
        button.show = true;
      });
    }
  }

}
