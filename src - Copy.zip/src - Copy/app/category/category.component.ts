import { Component, OnInit, ViewChild } from '@angular/core';
import { of, pipe } from 'rxjs';
import { filter, map } from 'rxjs/operators';

import { CategoryService } from '../shared/service/category.service';
import { ColumnConfig, _column } from '../shared/configs/columns';
import { TableConfig } from '../shared/configs/tables';
import { _constant } from '../shared/constant';
import { _button } from '../shared/configs/buttons';
import { Router } from '@angular/router';
import { DialogService } from '../shared/service/dialog.service';
import { NotificationService } from '../shared/service/notification.service';
import { _message } from '../shared/message';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})

export class CategoryComponent implements OnInit {

  constructor(private router: Router,
    private service: CategoryService,
    private notificationService: NotificationService,
    private dialogService: DialogService) { }

  @ViewChild('categoryGrid', { static: false }) categoryGrid?: any;
  table: TableConfig;

  columns: ColumnConfig[] = [
    {
      name: 'Id',
      field: 'id',
      type: 'number',
      // isHidden: true,
      isExpand: true,
    },
    {
      name: 'Name',
      field: 'name',
      type: 'string',
    },
    {
      name: 'Code',
      field: 'code',
      type: 'string',
    },
    {
      name: 'Description',
      field: 'description',
      type: 'string',
      isExpand: true,
    },
    {
      name: 'Rank',
      field: 'rank',
      type: 'number',
      isExpand: true,
    },
    {
      name: 'Active',
      field: 'isActive',
      type: 'checkbox',
    },
  ];

  addCallback = (data: any) => {
    this.router.navigate([this.table.tableId + '/add']);
  }

  addBtn: any = {
    name: 'add',
    title: 'Add',
    color: 'accent',
    role: 'add',
    callback: this.addCallback
  };

  editCallback = (data: any) => {
    this.router.navigate([this.table.tableId + '/edit/' + data.id]);
  }

  editBtn: any = {
    name: 'edit',
    title: 'Edit',
    color: 'primary',
    role: 'action',
    callback: this.editCallback
  };

  deleteCallback = (data: any) => {
    this.dialogService.openConfirmDialog(_message.deleteConfirm.replace('{0}', this.table.header))
      .afterClosed().subscribe((res: any) => {
        if (res) {
          this.service.deleteCategory(data.id).subscribe(
            () => {
              this.notificationService.success(_message.deleteSuccess.replace('{0}', this.table.header));
              this.categoryGrid.refreshDataSource();
            },
            (errObj: any) => {
              this.notificationService.danger(errObj.error.Message);
            });
        }
      });
  }

  deleteBtn: any = {
    name: 'delete',
    title: 'Delete',
    color: 'warn',
    role: 'action',
    callback: this.deleteCallback
  };

  getGridData = (paging?: any) => {
    return this.service.listCategory(paging);
  }

  getExpandData = (id: any) => {
    return this.service.expandCategory(id);
  }

  displayedColumns = this.columns
    .filter(column => !column.isExpand && !column.isHidden)
    .map(column => column.field);

  expandedColumns = pipe(
    filter((column: any) => column.isExpand && !column.isHidden)
    , map((column: any) => column.field)
  )(of(this.columns));

  ngOnInit(): void {
    this.setTableConfig();
  }

  setTableConfig() {
    this.table = {
      tableId: 'category',
      header: 'Category',
      columns: this.columns,
      buttons: [this.editBtn, this.deleteBtn],
      dataSource: this.getGridData,
      expandSource: this.getExpandData,
      showAdd: true,
      showSearch: true,
      showFilter: false,
      showAction: true,
      addBtn: this.addBtn,
      expandBtn: _button.expand,
      displayedColumns: [_column.expand.field, _column.index.field].concat(this.displayedColumns),
      expandedColumns: this.expandedColumns,
      defaultSort: { sortField: 'id', sortAsc: true }
    }

    if (this.table.showAdd) {
      // add button visibility
      this.table.addBtn.show = true;
    }

    if (this.table.showAction) {
      this.table.displayedColumns.push(_column.action.field);
      this.table.buttons.forEach((button: any) => {
        // edit & delete button visibility
        button.show = true;
      });
    }
  }

}
