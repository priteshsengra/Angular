import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { CategoryComponent } from './category.component';
import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { CategoryRoutingModule } from './category-routing.module';
import { TableModule } from '../shared/table/table.module';

@NgModule({
    declarations: [
        CategoryComponent,
        CategoryDetailComponent
    ],
    imports: [
        CommonModule,
        CategoryRoutingModule,
        MaterialModule,
        ReactiveFormsModule,
        FormsModule,
        TableModule
    ]
})
export class CategoryModule { }
