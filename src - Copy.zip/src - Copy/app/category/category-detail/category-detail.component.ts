import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { CategoryService } from 'src/app/shared/service/category.service';
import { NotificationService } from 'src/app/shared/service/notification.service';
import { _message } from 'src/app/shared/message';

@Component({
  selector: 'app-category-detail',
  templateUrl: './category-detail.component.html',
  styleUrls: ['./category-detail.component.css']
})

export class CategoryDetailComponent implements OnInit {
  _msg = _message;
  category_id: string;
  entity: string = 'category';
  entityText: string = 'Category';

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public service: CategoryService,
    public notificationService: NotificationService
  ) {
    this.route.params.subscribe(params => { this.category_id = params.id || 0; });
  }

  ngOnInit(): void {
    this.service.getCategory(this.category_id).subscribe(
      (data) => {
        let category = data;
        this.initializeFormGroup(category);
      },
      error => { console.log(error); });
  }

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', [Validators.required, Validators.minLength(5)]),
    code: new FormControl('', Validators.maxLength(5)),
    description: new FormControl('', Validators.maxLength(200)),
    rank: new FormControl(''),
    isActive: new FormControl(false),
  });

  initializeFormGroup(category?: any) {
    if (category) {
      this.form.setValue({
        id: category.id,
        name: category.name,
        code: category.code,
        description: category.description,
        rank: category.rank,
        isActive: category.isActive,
      });
    }
    else {
      this.form.setValue({
        id: '',
        name: '',
        code: '',
        description: '',
        rank: '',
        isActive: false,
      });
    }
  }

  _fc = this.form.controls;
  _fv = this.form.value;

  onSubmit() {
    if (this.form.valid) {
      let formObj = this.form.value;
      formObj.id = Number(formObj.id);

      let isEdit = formObj.id && formObj.id > 0;
      let serviceCall = isEdit
        ? this.service.updateCategory(formObj)
        : this.service.createCategory(formObj);

      serviceCall.subscribe(
        (data: any) => {
          this.notificationService.success(isEdit
            ? _message.editSuccess.replace('{0}', this.entityText)
            : _message.addSuccess.replace('{0}', this.entityText)
          );
          this.gotoList();
        },
        (error: any) => {
          console.log(error);
          this.notificationService.danger(isEdit
            ? _message.editError.replace('{0}', this.entityText)
            : _message.addError.replace('{0}', this.entityText)
          );
        });
    }
  }

  gotoList() {
    this.reset();
    this.router.navigate([this.entity]);
  }

  reset() {
    this.form.reset();
    this.initializeFormGroup();
  }

}
