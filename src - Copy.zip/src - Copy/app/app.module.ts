import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { DatePipe } from '@angular/common';
import { JwtModule } from "@auth0/angular-jwt";
import { DragDropModule } from '@angular/cdk/drag-drop';

import { AuthGuard } from './shared/service/auth-guard.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './shared/material/material.module';
import { MatConfirmDialogComponent } from './shared/mat-confirm-dialog/mat-confirm-dialog.component';
import { TableModule } from './shared/table/table.module';
import { ButtonModule } from './shared/button/button.module';
import { HomeComponent } from './shared/home/home.component';
import { LoginComponent } from './shared/login/login.component';
import { NavComponent } from './shared/nav/nav.component';
import { ExpandGridModule } from './shared/expand-grid/expand-grid.module';
import { FormModuleDetailComponent } from './form-module/form-module-detail/form-module-detail.component';
import { DragDropComponent } from './drag-drop/drag-drop.component';
import { FormModuleModule } from './form-module/form-module.module';
// import { ExpandGridComponent } from './shared/expand-grid/expand-grid.component';
// import { FormModuleComponent } from './form-module/form-module.component';

export function tokenGetter() {
  return localStorage.getItem("jwt");
}

@NgModule({
  declarations: [
    AppComponent,
    MatConfirmDialogComponent,
    HomeComponent,
    LoginComponent,
    NavComponent,
    FormModuleDetailComponent,
    DragDropComponent,
    // FormModuleComponent,
    // ExpandGridComponent,
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    TableModule,
    ButtonModule,
    ExpandGridModule,
    MatExpansionModule,
    FormModuleModule,
    DragDropModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        allowedDomains:["localhost:44312"],
        disallowedRoutes: []
      }
    })
  ],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    DatePipe, AuthGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [MatConfirmDialogComponent]
})
export class AppModule { }
