import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { FormModuleService } from '../shared/service/form-module.service';

@Component({
  selector: 'app-form-module',
  templateUrl: './form-module.component.html',
  styleUrls: ['./form-module.component.css']
})

export class FormModuleComponent implements OnInit {

  dataSource: any;
  showActive: boolean;

  constructor(private service: FormModuleService,
    private router: Router) { }

  addCallback = () => {
    this.router.navigate(['module/add']);
  }

  addBtn: any = {
    name: 'add',
    title: 'Add',
    color: 'accent',
    role: 'add',
    show: true,
    callback: this.addCallback
  };

  ngOnInit(): void {
    this.getAllData();
  }

  getAllData(showActive?: boolean) {
    showActive = showActive || this.showActive || false;
    this.service.listModule(showActive).subscribe(
      (data: any) => {
        this.dataSource = data;
      },
      (error: any) => {
        console.log(error);
      });
  }

  add() {
    this.router.navigate(['module/add']);
  }

  edit(record: any) {
    this.router.navigate(['module/edit/' + record.id]);
  }

  toggle(record: any) {
    this.service.toggleModule(record.id).subscribe(
      (data: any) => {
        record.isActive = data;
        this.getAllData();
      },
      (error: any) => {
        console.log(error);
      });
  }

  filterActive(showActive: boolean) {
    this.getAllData(showActive);
  }

  movies = [
    'Episode I - The Phantom Menace',
    'Episode II - Attack of the Clones',
    'Episode III - Revenge of the Sith',
    'Episode IV - A New Hope',
    'Episode V - The Empire Strikes Back',
    'Episode VI - Return of the Jedi',
    'Episode VII - The Force Awakens',
    'Episode VIII - The Last Jedi',
    'Episode IX - The Rise of Skywalker',
  ];

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.dataSource, event.previousIndex, event.currentIndex);
  }

}
