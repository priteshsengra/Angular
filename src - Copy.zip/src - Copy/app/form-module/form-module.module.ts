import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../shared/material/material.module';
import { FormModuleComponent } from './form-module.component';
import { FormRoutingModule } from './form-routing.module';
import { ButtonModule } from '../shared/button/button.module';
import { FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
// import { MdCardModule } from '@angular/material/';

@NgModule({
  declarations: [
    FormModuleComponent,
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormRoutingModule,
    ButtonModule,
    FormsModule,
    DragDropModule,
  ],
  exports: [
    FormModuleComponent,
  ]
})

export class FormModuleModule { }
