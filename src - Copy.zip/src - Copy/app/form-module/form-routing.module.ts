import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormModuleComponent } from './form-module.component';
import { FormModuleDetailComponent } from './form-module-detail/form-module-detail.component';

const routes: Routes = [
    { path: '', component: FormModuleComponent },
    { path: 'add', component: FormModuleDetailComponent },
    { path: 'edit/:id', component: FormModuleDetailComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FormRoutingModule { }
