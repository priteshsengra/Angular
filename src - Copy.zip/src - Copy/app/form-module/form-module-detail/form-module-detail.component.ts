import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
// import { from, Observable } from 'rxjs';

import { FormModuleService } from '../../shared/service/form-module.service';
import { NotificationService } from 'src/app/shared/service/notification.service';
import { _message } from 'src/app/shared/message';
import { _constant } from 'src/app/shared/constant';
import { _icons } from 'src/app/shared/icons';

@Component({
  selector: 'app-form-module-detail',
  templateUrl: './form-module-detail.component.html',
  styleUrls: ['./form-module-detail.component.css']
})

export class FormModuleDetailComponent implements OnInit {
  _msg = _message;
  _icn = _icons;
  module_id: string;
  // icons: any;

  constructor(
    public router: Router,
    public route: ActivatedRoute,
    public service: FormModuleService,
    public notificationService: NotificationService
  ) {
    this.route.params.subscribe(params => { this.module_id = params.id || 0; });
  }

  ngOnInit(): void {
    this.service.getModule(this.module_id).subscribe(
      (data) => {
        let module = data;
        this.initializeFormGroup(module);
      },
      error => { console.log(error); });
  }

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    name: new FormControl('', [Validators.required, Validators.minLength(5)]),
    prefix: new FormControl('', Validators.maxLength(5)),
    icon: new FormControl(''),
    isActive: new FormControl(false),
  });

  initializeFormGroup(module?: any) {
    if (module) {
      this.form.setValue({
        id: module.id,
        name: module.name,
        prefix: module.prefix,
        icon: module.icon,
        isActive: module.isActive,
      });
    }
    else {
      this.form.setValue({
        id: 0,
        name: '',
        prefix: '',
        icon: '',
        isActive: false,
      });
    }
  }

  _fc = this.form.controls;
  _fv = this.form.value;

  onSubmit() {
    if (this.form.valid) {
      let formObj = this.form.value;
      formObj.id = Number(formObj.id);

      let isEdit = formObj.id && formObj.id > 0;
      let serviceCall = isEdit
        ? this.service.updateModule(formObj)
        : this.service.createModule(formObj);

      serviceCall.subscribe(
        (data: any) => {
          this.notificationService.success(isEdit
            ? _message.editSuccess.replace('{0}', 'Module')
            : _message.addSuccess.replace('{0}', 'Module')
          );
          this.gotoList();
        },
        (error: any) => {
          console.log(error);
          this.notificationService.danger(isEdit
            ? _message.editError.replace('{0}', 'Module')
            : _message.addError.replace('{0}', 'Module')
          );
        });
    }
  }

  gotoList() {
    this.reset();
    this.router.navigate(['module']);
  }

  reset() {
    this.form.reset();
    this.initializeFormGroup();
  }

}
