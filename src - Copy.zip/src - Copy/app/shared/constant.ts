import { HttpHeaders } from "@angular/common/http";

export const _constant = {
    baseUrl: 'https://localhost:44312/',
    baseApiUrl: 'https://localhost:44312/Api/',
    productApiUrl: 'https://localhost:44312/Api/Product/',
    categoryApiUrl: 'https://localhost:44312/Api/Category/',
    moduleApiUrl: 'https://localhost:44312/Api/Module/',
    loginApiUrl: 'https://localhost:44312/Api/Login/',
    httpOptions: {
        // reportProgress: true, observe: 'events',
        headers: new HttpHeaders({
            'Content-Type': 'application/json'
        })
    },
    pageSizeOptions: [5, 10, 25, 50, 100],
    imagePath(fileSource: any) {
        return fileSource ? (_constant.baseUrl + fileSource) : _constant.defaultImg

        // if (fileSource) {
        //     return _constant.baseUrl + fileSource
        // }
        // else {
        //     return _constant.defaultImg
        // }
    },
    defaultImg: 'assets/images/default.png',
    apiFolderPath: 'Resource/Images/',
};