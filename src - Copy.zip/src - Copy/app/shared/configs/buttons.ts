
export interface ButtonConfig {
  name: string;
  title: string;
  color: string;
  callback: Function;
  role?: string | '';
  show?: boolean | false;
  // style?: string | '';
}

export const _button = {
  add: {
    name: 'add',
    title: 'Add',
    color: 'accent',
    role: 'add',
    // callback: function () { }
  },
  edit: {
    name: 'edit',
    title: 'Edit',
    color: 'primary',
    role: 'action',
  },
  delete: {
    name: 'delete',
    title: 'Delete',
    color: 'warn',
    role: 'action',
  },
  expand: {
    name: 'arrow_right',
    title: 'Expand',
    color: '',
    role: 'expand',
    callback: function () { },
    // show: true,
  },

}
