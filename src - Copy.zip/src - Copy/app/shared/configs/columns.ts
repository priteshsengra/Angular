
export interface ColumnConfig {
  name: string;
  field: string;
  type: string;
  isHidden?: boolean | false;
  isExpand?: boolean | false;
}

export const _column = {
  type: {
    string: 'string',
    number: 'number',
    currency: 'currency',
    date: 'date',
    checkbox: 'checkbox',
    file: 'file'
  },
  expand: {
    name: 'Expand',
    field: 'button',
    type: 'button'
  },
  index: {
    name: 'Sr. No.',
    field: 'index',
    type: 'index'
  },
  action: {
    name: 'Action',
    field: 'actions',
    type: 'action',
  }
}