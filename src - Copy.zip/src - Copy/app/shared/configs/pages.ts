
export interface Paging {
  searchString: string;
  sortField: string;
  sortAsc: boolean;
  pageNum: number;
  pageSize: number;
}

export interface DefaultSort {
  sortField: string;
  sortAsc: boolean;
}
