import { Observable } from 'rxjs';
import { ButtonConfig } from './buttons';
import { ColumnConfig } from './columns';
import { DefaultSort } from './pages';

export interface TableConfig {
  tableId: string;
  header: string;
  columns: ColumnConfig[];
  buttons: ButtonConfig[];
  defaultSort: DefaultSort;
  addBtn: ButtonConfig;

  displayedColumns: string[];
  dataSource: Function;
  // expandedColumns?: string[];
  expandedColumns?: Observable<string>;
  expandSource: Function;
  expandBtn: ButtonConfig;

  showAdd?: boolean | false;
  showSearch?: boolean | false;
  showFilter?: boolean | false;
  showAction?: boolean | false;
}
