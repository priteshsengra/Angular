import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { _constant } from '../constant';

@Injectable({
  providedIn: 'root'
})

export class LoginService {

  url = _constant.loginApiUrl;
  httpOptions = _constant.httpOptions;

  constructor(private http: HttpClient) { }

  login(login: any): any {
    return this.http.post(this.url + 'Authorize', login, this.httpOptions);
  }

}
