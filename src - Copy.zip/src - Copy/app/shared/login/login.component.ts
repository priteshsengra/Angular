import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import { LoginService } from './login.service';
import { NotificationService } from '../service/notification.service';
import { _message } from '../message';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean;

  constructor(
    private jwtHelper: JwtHelperService,
    public router: Router,
    private service: LoginService,
    private notificationService: NotificationService) { }

  invalidCredentials = _message.invalidCredentials;
  loginHeader = _message.loginHeader;

  ngOnInit(): void {
    const token: string | null = localStorage.getItem("jwt");
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      this.router.navigate(['/']);
    }
  }

  form: FormGroup = new FormGroup({
    id: new FormControl(''),
    username: new FormControl(''),
    password: new FormControl('')
  });

  login(form: NgForm) {
    if (form.valid) {
      const credentials = JSON.stringify(form.value);
      this.service.login(credentials).subscribe((response: any) => {
        const token = response.token;
        localStorage.setItem("jwt", token);
        this.invalidLogin = false;
        this.notificationService.success(_message.loginSuccess);
        this.router.navigate(["/"]);
      }, (err: any) => {
        this.invalidLogin = true;
        this.notificationService.danger(_message.loginError);
      });
    }
  }

}
