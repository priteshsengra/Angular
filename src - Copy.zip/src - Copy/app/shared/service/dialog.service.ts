import { MatConfirmDialogComponent } from '../mat-confirm-dialog/mat-confirm-dialog.component';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Injectable({
  providedIn: 'root'
})
export class DialogService {

  constructor(private dialog: MatDialog) { }

  setConfig(msg: any) {
    return {
      width: '390px',
      panelClass: 'confirm-dialog-container',
      disableClose: true,
      position: { top: "10%" },
      data: {
        message: msg
      }
    }
  };

  openConfirmDialog(msg: any) {
    return this.dialog.open(MatConfirmDialogComponent, this.setConfig(msg));
  }
}