import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { _constant } from '../constant';

@Injectable({
  providedIn: 'root'
})

export class BaseApiService {

  url = _constant.baseApiUrl;
  constructor(private http: HttpClient) { }

  list(entity: any, paging: any, categoryId?: any): Observable<any> {
    // if (categoryId) {
    //   return this.http.post(this.url + entity + '/List?categoryId=' + categoryId, paging, _constant.httpOptions);
    // }
    // else {
    //   return this.http.post(this.url + entity + '/List', paging, _constant.httpOptions);
    // }

    return this.http.post(this.url + entity + '/List?categoryId=' + categoryId, paging, _constant.httpOptions);
  }

  get(entity: any, id: string): Observable<any> {
    return this.http.get(this.url + entity + '/Get/' + id);
  }

  expand(entity: any, id: any): any {
    return this.http.get(this.url + entity + '/Expand/' + id);
  }

  create(entity: any, addObj: any): any {
    return this.http.post(this.url + entity + '/Create', addObj);
  }

  update(entity: any, editObj: any): any {
    return this.http.put(this.url + entity + '/Update', editObj);
  }

  delete(entity: any, id: string) {
    return this.http.delete(this.url + entity + '/Delete/' + id, _constant.httpOptions);
  }

}
