import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseApiService } from './base-api.service';
import { _constant } from '../constant';

@Injectable({
  providedIn: 'root'
})

export class CategoryService {

  // url = _constant.categoryApiUrl;
  entity = 'Category';
  constructor(private service: BaseApiService) { }

  listCategory(paging: any): Observable<any> {
    return this.service.list(this.entity, paging);
    // return this.http.post(this.url + 'List', paging, _constant.httpOptions);
  }

  getCategory(id: string): Observable<any> {
    return this.service.get(this.entity, id);
    // return this.http.get(this.url + 'Get/' + id);
  }

  expandCategory(id: string): any {
    return this.service.expand(this.entity, id);
    // return this.http.get(this.url + 'Expand/' + id);
  }

  createCategory(category: any): any {
    return this.service.create(this.entity, category);
    // return this.http.post(this.url + 'Create', category, _constant.httpOptions);
  }

  updateCategory(category: any): any {
    return this.service.update(this.entity, category);
    // return this.http.put(this.url + 'Update', category, _constant.httpOptions);
  }

  deleteCategory(id: string) {
    return this.service.delete(this.entity, id);
    // return this.http.delete(this.url + 'Delete/' + id, _constant.httpOptions);
  }

}