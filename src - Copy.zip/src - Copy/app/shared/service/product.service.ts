import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseApiService } from './base-api.service';
import { _constant } from '../constant';

@Injectable({
  providedIn: 'root'
})

export class ProductService {

  // url = _constant.productApiUrl;
  entity = 'Product';
  constructor(private service: BaseApiService) { }

  listProduct(paging: any, categoryId: any): Observable<any> {
    return this.service.list(this.entity, paging, categoryId);
    //   return this.http.post(this.url + 'List?categoryId=' + categoryId, paging, _constant.httpOptions);
  }

  getProduct(id: string): Observable<any> {
    return this.service.get(this.entity, id);
    //   return this.http.get(this.url + 'Get/' + id);
  }

  expandProduct(id: any): any {
    return this.service.expand(this.entity, id);
    //   return this.http.get(this.url + 'Expand/' + id);
  }

  createProduct(productForm: any): any {
    return this.service.create(this.entity, productForm);
    //   return this.http.post(this.url + 'Create', productForm);
  }

  updateProduct(productForm: any): any {
    return this.service.update(this.entity, productForm);
    //   return this.http.put(this.url + 'Update', productForm);
  }

  deleteProduct(id: string) {
    return this.service.delete(this.entity, id);
    //   return this.http.delete(this.url + 'Delete/' + id, _constant.httpOptions);
  }

}