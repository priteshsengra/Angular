import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { _constant } from '../constant';
import { BaseApiService } from './base-api.service';

@Injectable({
  providedIn: 'root'
})

export class FormModuleService {

  url = _constant.moduleApiUrl;
  entity = 'Module';
  constructor(private http: HttpClient, private service: BaseApiService) { }

  listModule(showActive: boolean): Observable<any> {
    return this.http.get(this.url + 'List/' + showActive);
  }

  getModule(id: string): Observable<any> {
    return this.service.get(this.entity, id);
    // return this.http.get(this.url + 'Get/' + id);
  }

  createModule(module: any): any {
    return this.service.create(this.entity, module);
    // return this.http.post(this.url + 'Create', module, _constant.httpOptions);
  }

  updateModule(module: any): any {
    return this.service.update(this.entity, module);
    // return this.http.put(this.url + 'Update', module, _constant.httpOptions);
  }

  toggleModule(id: any): any {
    return this.http.get(this.url + 'Toggle/' + id);
  }

  // deleteModule(id: string) {
  //   return this.service.delete(this.entity, id);
  //   // return this.http.delete(this.url + 'Delete/' + id, _constant.httpOptions);
  // }

}
