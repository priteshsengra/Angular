export const _message = {
    required: '{0} is required.',
    minChar: 'Minimum {0} characters required.',
    maxChar: 'Maximum {0} characters allowed.',
    minValue: '{0} should be greater than {1}.',
    maxValue: '{0} should be less than {1}.',
    select: 'Please select {0}.',

    deleteConfirm: 'Are you sure you want to delete this {0} ?',

    addSuccess: 'Successfully Added this {0}.',
    editSuccess: 'Successfully Updated this {0}.',
    deleteSuccess: 'Successfully Deleted this {0}.',

    addError: 'Could not Add this {0}.',
    editError: 'Could not Update this {0}.',
    deleteError: 'Could not Delete this {0}.',

    loginSuccess: 'Successfully Logged In.',
    logoutSuccess: 'Successfully Logged Out.',

    loginError: 'Unable to Login.',
    logoutError: 'Unable to Logout.',
    
    invalidCredentials: 'Invalid Username or Password.',
    loginHeader: 'Please Login to continue.',
    welcomeMsg: 'Welcome User.'
}
