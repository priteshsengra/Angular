import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { _message } from '../message';
import { NotificationService } from '../service/notification.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  ngOnInit(): void {}

  welcomeMsg = _message.welcomeMsg;
  loginHeader = _message.loginHeader;

  constructor(private jwtHelper: JwtHelperService,
    private notificationService: NotificationService,
    private router: Router) { }

  public isUserAuthenticated() {
    const token: string | null = localStorage.getItem("jwt");
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    }
    else {
      this.router.navigate(['login']);
      return false;
    }
  }

  public logOut = () => {
    localStorage.removeItem("jwt");
    this.notificationService.success(_message.logoutSuccess);
    this.router.navigate(['login']);
  }

}
