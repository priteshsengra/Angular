import { Component, Input } from '@angular/core';
import { _constant } from '../constant';

@Component({
  selector: 'app-expand-grid',
  templateUrl: './expand-grid.component.html',
  styleUrls: ['./expand-grid.component.css']
})
export class ExpandGridComponent {

  @Input() element: any;
  @Input() entity: any;
  _const = _constant;
  
  constructor() { }

}
