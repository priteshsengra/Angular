import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExpandGridComponent } from './expand-grid.component';

@NgModule({
  declarations: [
    ExpandGridComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ExpandGridComponent
  ]
})
export class ExpandGridModule { }
