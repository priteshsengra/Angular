import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ButtonConfig } from '../configs/buttons';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {

  @Input() button: ButtonConfig;
  @Input() class: string;
  
  @Output() onClick = new EventEmitter<any>();

  constructor() { }
 
  buttonClick() {
    this.onClick.emit();
  }
}