import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';

import { MaterialModule } from '../material/material.module';
import { ButtonModule } from '../button/button.module';
import { ExpandGridModule } from '../expand-grid/expand-grid.module';
import { TableComponent } from './table.component';

@NgModule({
  declarations: [
    TableComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MatExpansionModule,
    MaterialModule,
    ButtonModule,
    ExpandGridModule,
  ],
  exports: [
    TableComponent
  ]
})
export class TableModule { }
