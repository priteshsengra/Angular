import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { animate, state, style, transition, trigger } from '@angular/animations';

import { NotificationService } from '../service/notification.service';
import { TableConfig } from '../configs/tables';
import { Paging } from '../configs/pages';
import { _column } from '../configs/columns';
import { _constant } from '../constant';
import { _button } from '../configs/buttons';
import { _message } from '../message';
// import { ProductComponent } from 'src/app/product/product.component';
// import { String } from './shared/configs/interface';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class TableComponent implements OnInit {

  @Input() table: TableConfig;

  paging: Paging;
  _col = _column;
  _const = _constant;

  dataSource: any;
  totalRecords: number;
  filteredRecords: number;
  categoryList: any;
  categoryId: number;
  expandedElement: any | null;
  expandDataSource: any;

  constructor(private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.paging = this.resetPaging();
    this.refreshDataSource(this.paging, this.categoryId);
  }

  search() {
    this.paging.pageNum = 0;
    this.refreshDataSource(this.paging, this.categoryId);
  }

  clearSearch() {
    this.paging.searchString = '';
    this.search();
  }

  capitalise(value: string) {
    return value.substr(0, 1).toUpperCase() + value.substr(1);
  }

  sort(sortField: string) {
    this.paging.sortField = this.capitalise(sortField);
    this.paging.sortAsc = !this.paging.sortAsc;
    this.refreshDataSource(this.paging, this.categoryId);
  }

  loadExpandData(element: any) {
    // Only call Api if element doesn't have child.
    if (element && !element.child) {
      this.table.expandSource(element.id).subscribe(
        (data: any) => {
          element.child = data;
        },
        (errObj: any) => {
          this.notificationService.danger(errObj.error.Message);
        });
    }
  }

  pageChanged(event: PageEvent) {
    this.paging.pageSize = event.pageSize;
    this.paging.pageNum = event.pageIndex;
    this.refreshDataSource(this.paging, this.categoryId);
  }

  resetPaging() {
    return {
      searchString: '',
      sortField: this.capitalise(this.table.defaultSort.sortField),
      sortAsc: this.table.defaultSort.sortAsc,
      pageNum: 0,
      pageSize: _constant.pageSizeOptions[0]
    };
  }

  refreshDataSource(paging?: any, categoryId?: any) {
    paging = paging || this.paging;
    categoryId = categoryId || this.categoryId || 0;
    this.table.dataSource(paging, categoryId).subscribe(
      (response: any) => {
        let data = response.list;
        this.dataSource = data.list;
        this.categoryList = response.categoryList;

        this.paging = this.paging || this.resetPaging();
        this.totalRecords = data.totalRecords;
        this.filteredRecords = data.filteredRecords;
        if (data.filteredRecords == 0) {
          this.paging.pageNum > 0 ? this.paging.pageNum-- : 0;
          this.refreshDataSource(this.paging, this.categoryId);
        }
      },
      (error: any) => {
        console.log(error);
      });
  }

}
