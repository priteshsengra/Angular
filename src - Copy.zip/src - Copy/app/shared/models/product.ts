
export interface Product {
    id: number;
    name: string;
    description: string;
    price: number;
    quantity: number;
    typeName: string;
    categoryId: number;
    mfgDate: Date;
    isActive: boolean;
    fileSource: string;
    files?: File | null;
}
