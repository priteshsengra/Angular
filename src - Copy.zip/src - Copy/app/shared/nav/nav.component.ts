import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { NotificationService } from '../service/notification.service';
import { _message } from '../message';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  ngOnInit(): void {
  }

  constructor(private jwtHelper: JwtHelperService,
    private notificationService: NotificationService,
    private router: Router) { }

  public isUserAuthenticated() {
    const token: string | null = localStorage.getItem("jwt");
    if (token && !this.jwtHelper.isTokenExpired(token)) {
      return true;
    }
    else {
      return false;
      // this.router.navigate(['login']);
    }
  }

  public logOut = () => {
    localStorage.removeItem("jwt");
    this.notificationService.success(_message.logoutSuccess);
    this.router.navigate(['login']);
  }

}
